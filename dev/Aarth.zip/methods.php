<?php
include("lib/lib.php");

switch(strtolower($_GET['a'])) {
	case 'emailinuse':
		// USES REQUEST VALUE OF E TO FIND THE EMAIL ADDRESS
		$EmailAddress = $_REQUEST['e'];
		$DB = new Database();
		$InUse = $DB->IsEmailInUse($EmailAddress);
		$IsInUse = ($InUse >0) ? true :false;
		print(JSONResponse::PrepareResponse($IsInUse, "", $InUse));
	break;
	case 'commitnewuser':
		if(isset($_REQUEST['e'])) {
			$EmailAddress = $_REQUEST['e'];
		}else{
			return;	
		}
		if(isset($_REQUEST['p'])) {
			$Password = $_REQUEST['p'];
		}else{
			return;
		}
		if(isset($_REQUEST['s'])) {
			$CreateSession = $_REQUEST['s'] == "true" ? true : false;
		}else{
			return;	
		}
		$DB = new Database();
		$RowsAffected = $DB->CommitUserToDatabase($EmailAddress, $Password);
		$Created = ($RowsAffected >0) ? true :false;
		if($Created && $CreateSession) {
			UserManagement::CreateSession($EmailAddress);	
		}
		print(JSONResponse::PrepareResponse($Created, "Creation status enclosed", $Created));
	break;
	case 'validateusercredentials':
		if(isset($_REQUEST['e'])) {
			$EmailAddress = $_REQUEST['e'];
		}else{
			return;	
		}
		if(isset($_REQUEST['p'])) {
			$Password = $_REQUEST['p'];
		}else{
			return;
		}
		if(isset($_REQUEST['s'])) {
			$CreateSession = $_REQUEST['s'] == "true" ? true : false;
		}else{
			return;	
		}
		$DB = new Database();
		$InUse = $DB->ValidateUserCredentials($EmailAddress, $Password);
		$ValidCredentials = ($InUse >0) ? true :false;
		if($ValidCredentials && $CreateSession) {
			UserManagement::CreateSession($EmailAddress);	
		}
		print(JSONResponse::PrepareResponse($ValidCredentials, "Authentication status enclosed", $InUse));
	break;
	
	case 'destroysession':
		UserManagement::DestroySession();
		print(JSONResponse::PrepareResponse(true, "Destroyed", null));
	break;
}

?>