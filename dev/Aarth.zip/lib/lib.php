<?php

class UserManagement {
	public static function CreateSession($EmailAddress) {
		UserManagement::InitSession();
		$_SESSION['EmailAddress'] = $EmailAddress;
	}
	
	public static function DestroySession() {
		UserManagement::InitSession();
		session_destroy();
	}
	
	public static function InitSession() {
		//if(session_status() != PHP_SESSION_ACTIVE) {
		@session_start();	
		//}
	}
}

class Database {
	private $Host = "127.0.0.1";
	private $Database  = "aarth_users";
	private $Username = "aarth";
	private $Password = "passwordtbd";
	private $MySQLi;
	
	private function Connect() {
		try{
			$this->MySQLi = new mysqli($this->Host, $this->Username, $this->Password, $this->Database);
		}catch(PDOException $e) {
			echo 'Connection failed: ' . $e->getMessage();
		}
	}
	
	public function IsEmailInUse($Email) {
		$this->Connect();
		$InUse = null;
		if($Statement = $this->MySQLi->prepare("SELECT COUNT(*) Rows FROM users WHERE users.user_email = ?")) {
			$Statement->bind_param("s", $Email);
			$Statement->execute();
			$InUse = null;
			$Statement->bind_result($InUse);
			$Statement->fetch();
			$Statement->close();
		}
		$this->Disconnect();
		return ($InUse>0 ? true : false);
	}
	
	public function ValidateUserCredentials($Email, $Password) {
		$this->Connect();
		$InUse = null;
		$HashedPassword = Hash::GenerateHash($Password);
		if($Statement = $this->MySQLi->prepare("SELECT COUNT(*) Rows FROM users WHERE users.user_email = ? AND users.password_sha256_hash = ?")) {
			$Statement->bind_param("ss", $Email, $HashedPassword);
			$Statement->execute();
			$InUse = null;
			$Statement->bind_result($InUse);
			$Statement->fetch();
			$Statement->close();
		}
		$this->Disconnect();
		return ($InUse>0 ? true : false);
	}
	
	public function CommitUserToDatabase($Email, $Password) {
		$this->Connect();
		$InUse = null;
		$HashedPassword = Hash::GenerateHash($Password);
		if($Statement = $this->MySQLi->prepare("INSERT INTO users (user_email, password_sha256_hash) VALUES (?,?)")) {
			$Statement->bind_param("ss", $Email, $HashedPassword);
			$Statement->execute();
			$Rows = $this->MySQLi->affected_rows;
			if($Rows == 1) {
				UserManagement::CreateSession($Email);
			}
			$Statement->close();
		}
		$this->Disconnect();
		return ($Rows==1 ? true : false);
	}
	
	private function Disconnect() {
		$this->MySQLi->close();
	}
}

class Hash {
	public static function GenerateHash($IncomingString) {
		return hash('sha256',$IncomingString);
	}
}

class JSONResponse {
	public static function PrepareResponse($Success, $Message, $Data) {
		$StringSuccess = $Success == true ? "Success" : "Failure";
		$EncodedData = json_encode($Data);
		$Output = "{\"response\":{\"result\":\"".$StringSuccess."\", \"message\":\"".$Message."\", \"data\":".$EncodedData."}}";
		return $Output;
	}	
}


?>